var period = 1000; // 1 second
var interval = setInterval(function() {
  console.log('tick');
}, period);