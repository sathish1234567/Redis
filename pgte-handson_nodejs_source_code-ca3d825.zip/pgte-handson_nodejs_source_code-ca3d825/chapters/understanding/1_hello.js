setTimeout(function() {
  console.log('World!');
}, 2000);
console.log('Hello');